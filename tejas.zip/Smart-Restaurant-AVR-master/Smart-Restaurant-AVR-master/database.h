#ifndef IO_H
#define IO_H

#include "Arduino.h"
#include "LiquidCrystal.h"
#include "io.h"

void get_info();



#endif
